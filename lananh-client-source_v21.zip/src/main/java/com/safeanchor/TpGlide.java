package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/**
 * Trượt mượt khi bị tp (pearl, chorus fruit, /tp...): vị trí thật vẫn tới nơi ngay, nhưng CAMERA lướt từ chỗ cũ
 * sang chỗ mới trong vài trăm ms (cảm giác lao tới) thay vì giật cái là đứng ở chỗ mới.
 * Camera được dịch trong CameraMixin (gọi offset()).
 */
public class TpGlide {
    static Vec3d last;
    static Object lastWorld;
    static Vec3d off = Vec3d.ZERO;
    static long start;

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (p == null || mc.world == null) { last = null; off = Vec3d.ZERO; return; }
        Vec3d now = p.getPos();
        if (lastWorld != mc.world) { lastWorld = mc.world; last = now; off = Vec3d.ZERO; return; }   // đổi thế giới: không trượt
        if (c.tpGlide && c.enabled && last != null && !p.hasVehicle()) {
            double d = now.distanceTo(last);
            if (d >= Math.max(2.0, c.tpMin) && d <= 400) {
                Vec3d cur = offset();                       // đang trượt dở thì cộng dồn
                Vec3d vis = last.add(cur == null ? Vec3d.ZERO : cur);   // chỗ camera đang ở (theo thế giới)
                off = vis.subtract(now);
                start = System.currentTimeMillis();
            }
        }
        last = now;
    }

    /** Độ lệch cần cộng vào vị trí camera, hoặc null nếu không trượt. */
    public static Vec3d offset() {
        Config c = Config.I;
        if (off == null || (off.x == 0 && off.y == 0 && off.z == 0)) return null;
        if (!c.tpGlide || !c.enabled) return null;
        double ms = Math.max(100, c.tpMs);
        double t = (System.currentTimeMillis() - start) / ms;
        if (t >= 1.0) { off = Vec3d.ZERO; return null; }
        double e = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;    // nhanh dần rồi chậm lại
        double k = 1.0 - e;
        return new Vec3d(off.x * k, off.y * k, off.z * k);
    }
}
