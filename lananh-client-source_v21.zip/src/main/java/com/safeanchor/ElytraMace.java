package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Elytra + Mace tự động.
 * Bình thường: cất cánh -> bay lên cao hơn đối thủ -> (cánh -> áo, vì mace chỉ smash khi KHÔNG bay) -> rơi xuống đập.
 * Chuỗi đập: vừa đập xong bị hất lên nhẹ -> KHÔNG bay lên cao nữa, dùng cánh lao thẳng xuống đối thủ rồi đập tiếp.
 */
public class ElytraMace {
    static boolean diving, keysHeld, quick, hitFlag;
    static int stage;   // 0 = còn đeo cánh, bay tới gần đối thủ; 1 = đã đổi áo, rơi đập
    static int cd, rocketCd, axeCd;
    public static int chain;   // số tick còn lại của "chuỗi đập"
    static double tvx, tvz;    // vận tốc ngang của đối thủ (block / tick)
    static PlayerEntity lastT; static Vec3d lastTp;
    static boolean spamAllOn; static int spamAll;
    static boolean jumpPulse, spamOn; static int jumpCd, spamT;   // spamT: số tick đã spam Space để mở elytra
    static boolean overhead; static int ascT;      // đã bay tới gần phía trên đối thủ / số tick bay lên mà chưa lao xuống
    static PlayerEntity locked;                  // mục tiêu đang khóa (chỉ đánh đúng 1 người cho tới khi chết / mất)
    static Vec3d seen; static int searchT;   // chỗ thấy đối thủ lần cuối + số tick đã bay tìm

    public static void toggle(MinecraftClient mc) {
        Config.I.autoMace = !Config.I.autoMace;
        if (mc.player == null) { Config.save(); return; }   // đang ở menu chính (Mod Menu), chưa vào game
        if (!Config.I.autoMace) release(mc);
        Util.msg("Elytra Mace: " + (Config.I.autoMace ? "§aBẬT" : "§cTẮT"));
        Config.save();
    }

    /** Gọi mỗi khi đập đối thủ bằng mace (tự đập hoặc bạn tự bấm). */
    public static void onHit() {
        if (!Config.I.autoMace) return;
        if (Config.I.maceChain) chain = 80;
        hitFlag = true;
    }

    static void release(MinecraftClient mc) {
        if (keysHeld) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); keysHeld = false; }
        diving = false; stage = 0; quick = false; hitFlag = false; overhead = false; ascT = 0; spamT = 0; spamOn = false;
    }

    /** Từ lúc BẬT Elytra Mace tới lúc TẮT: tự spam Space liên tục (bấm - nhả mỗi tick) để elytra luôn mở được ngay. */
    public static void tick(MinecraftClient mc) {
        tickLogic(mc);
        Config c = Config.I; var p = mc.player;
        if (c.autoMace && c.enabled && c.maceSpamJump && p != null && mc.world != null && mc.currentScreen == null && !p.isSpectator() && !p.isDead()) {
            mc.options.jumpKey.setPressed((spamAll++ & 1) == 0);
            keysHeld = true; spamAllOn = true;
        } else if (spamAllOn) { mc.options.jumpKey.setPressed(false); spamAllOn = false; }
    }

    static void tickLogic(MinecraftClient mc) {
        Config c = Config.I;
        var p = mc.player;
        if (!c.autoMace || !c.enabled || p == null || mc.world == null || mc.interactionManager == null) { locked = null; if (keysHeld) release(mc); return; }
        if (p.isSpectator() || p.isDead()) return;
        if (jumpPulse) { mc.options.jumpKey.setPressed(false); jumpPulse = false; }      // mỗi lần nhảy chỉ bấm đúng 1 nhịp
        if (jumpCd > 0) jumpCd--;
        if (cd > 0) cd--;
        if (rocketCd > 0) rocketCd--;
        if (axeCd > 0) axeCd--;
        if (chain > 0) chain--;

        PlayerEntity t = pickTarget(mc);
        if (t == null) {
            lastT = null;
            if (c.maceSearch && searchStep(mc)) return;     // không thấy ai -> bay đi tìm
            release(mc); return;
        }
        seen = t.getPos(); searchT = 0;
        if (lastT == t && lastTp != null) { tvx = t.getX() - lastTp.x; tvz = t.getZ() - lastTp.z; } else { tvx = 0; tvz = 0; }
        if (Math.hypot(tvx, tvz) > 1.6) { tvx = 0; tvz = 0; }      // pearl / tp: không dùng làm vận tốc
        lastT = t; lastTp = t.getPos();

        if (p.getHealth() + p.getAbsorptionAmount() < c.minSelfHealth) {
            release(mc);
            if (c.maceSwapChest && cd == 0 && Util.chestIs(Util::isElytra)) { Util.equipChest(Util::isChestplate, true); cd = 5; }
            Util.warn("Máu thấp - Elytra Mace tạm dừng");
            return;
        }

        switch (c.maceView) {
            case 1 -> mc.options.setPerspective(Perspective.FIRST_PERSON);
            case 2 -> mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            case 3 -> mc.options.setPerspective(Perspective.THIRD_PERSON_FRONT);
            default -> {}
        }

        double above = p.getY() - t.getY();
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double dist = Util.distToBox(p.getEyePos(), t.getBoundingBox());

        if (diving) { dive(mc, t, dist); return; }
        hitFlag = false;

        // ===== CHUỖI ĐẬP: vừa đập, đang bị hất lên nhẹ -> đeo cánh rồi lao xuống đập tiếp =====
        if (c.maceChain && c.maceStyle == 0 && chain > 0 && !p.isOnGround() && horiz <= c.maceHorizDive && above >= 4) {   // đang đủ cao -> lao xuống luôn
            if (cd > 0) return;
            if (!Util.chestIs(Util::isElytra)) { if (Util.equipChest(Util::isElytra, false)) cd = 2; return; }
            diving = true; stage = 0; quick = true; cd = 0;
            return;
        }

        // ===== GIAI ĐOẠN BAY LÊN =====
        if (cd > 0) return;
        if (!Util.chestIs(Util::isElytra)) {
            if (Util.equipChest(Util::isElytra, false)) { cd = 3; } else { Util.warn("Không có elytra trong túi!"); }
            return;
        }
        if (openElytra(mc)) return;                 // cất cánh + mở elytra (spam Space)
        // Chốt "đã tới phía trên" (có độ trễ) để không còn nhảy qua lại giữa bay thấp đuổi / bay cao => hết bay vòng vòng
        if (horiz > c.maceHorizDive * 2 + 20) overhead = false; else if (horiz <= c.maceHorizDive + 4) overhead = true;
        boolean chasing = c.maceChase && !overhead && horiz > c.maceHorizDive + 4;      // đối thủ chạy / pearl xa -> bay đón đầu
        // vừa đập xong (chuỗi đập): chỉ "nhảy" lên cao ~Hop block rồi lao xuống đập tiếp, KHÔNG bay lên tận độ cao lao ban đầu => đánh liên tục
        boolean fast = c.maceChain && chain > 0;
        double dd = fast ? Math.min(c.maceQuickH, c.maceDiveDist) : c.maceDiveDist;
        double aimAlt = Math.min(312, t.getY() + dd + (fast ? 3 : 8));                   // không đòi cao hơn giới hạn thế giới
        double needAbove = Math.min(dd, Math.max(fast ? 4 : 6, 312 - t.getY()));
        Vec3d aim;
        if (chasing) {
            double lead = Math.min(20, horiz / 1.4);
            aim = new Vec3d(t.getX() + tvx * lead, t.getY() + Math.max(6, dd * 0.5), t.getZ() + tvz * lead);
        } else aim = new Vec3d(t.getX() + tvx * 3, aimAlt, t.getZ() + tvz * 3);          // lên cao mà vẫn bám theo đối thủ
        Util.aim(p, aim);
        rocket(mc, c.maceStyle == 1 ? 2 : chasing ? 1 : 0);
        ascT++;
        boolean relax = ascT > 120;                                                      // bay lên quá lâu mà chưa lao -> nới điều kiện
        if (above >= (relax ? Math.max(6, needAbove * 0.5) : needAbove) && horiz <= c.maceHorizDive * (relax ? 2 : 1)) { diving = true; stage = 0; quick = false; cd = 0; ascT = 0; }
    }

    /**
     * Mở elytra: SPAM Space liên tục (nhảy rồi bấm Space lần nữa giữa không trung) cho tới khi bay được; đồng thời gửi lệnh mở cánh khi bắt đầu rơi.
     * Trả về true nếu CHƯA bay (đang mở cánh), false nếu đã bay. Hết số tick spam mà chưa bay thì nghỉ ~1s rồi spam lại.
     */
    static boolean openElytra(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (p.isGliding()) {
            if (spamOn) { mc.options.jumpKey.setPressed(false); spamOn = false; }
            spamT = 0;
            return false;
        }
        spamT++;
        if (c.maceSpamJump && spamT <= c.maceSpamTicks) {
            mc.options.jumpKey.setPressed((spamT & 1) == 1);       // bấm - nhả - bấm - nhả... mỗi tick đổi trạng thái
            spamOn = true; keysHeld = true;
        } else {
            if (spamOn) { mc.options.jumpKey.setPressed(false); spamOn = false; }
            if (!c.maceSpamJump && p.isOnGround() && jumpCd == 0) { mc.options.jumpKey.setPressed(true); jumpPulse = true; jumpCd = 12; keysHeld = true; }
            if (spamT > c.maceSpamTicks + 20) spamT = 0;
        }
        if (!p.isOnGround() && p.getVelocity().y < 0) {              // đang rơi -> mở cánh
            p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            p.startGliding();
        }
        return true;
    }

    /** Khóa 1 mục tiêu duy nhất: chọn người gần nhất rồi giữ nguyên tới khi họ chết / thoát / ra khỏi tầm, không nhảy qua người khác. */
    static PlayerEntity pickTarget(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (c.maceLock && locked != null) {
            boolean ok = locked.isAlive() && !locked.isRemoved() && !locked.isSpectator() && mc.world.getPlayers().contains(locked)
                    && locked.squaredDistanceTo(p) <= c.maceRange * c.maceRange;
            if (ok) return locked;
            locked = null;
        }
        PlayerEntity t = Util.nearestEnemy(c.maceRange);
        locked = c.maceLock ? t : null;
        return t;
    }

    /** Không thấy đối thủ trong tầm: bay elytra tới chỗ thấy lần cuối rồi vòng xoắn rộng dần để tìm. Trả về false khi hết giờ tìm (hoặc không bay được). */
    static boolean searchStep(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (p.getHealth() + p.getAbsorptionAmount() < c.minSelfHealth) return false;
        if (searchT >= c.maceSearchSec * 20) {                // hết giờ: lượn nhẹ xuống đất rồi dừng
            if (p.isGliding() && !p.isOnGround()) { p.setPitch(8f); return true; }
            return false;
        }
        if (cd > 0) return true;
        if (!Util.chestIs(Util::isElytra)) { if (Util.equipChest(Util::isElytra, false)) { cd = 3; return true; } return false; }
        if (openElytra(mc)) { searchT++; return true; }
        searchT++;
        double top = w.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, p.getBlockX(), p.getBlockZ());
        double alt = Math.min(315, top + 35);
        Vec3d aim;
        if (seen != null && p.getPos().squaredDistanceTo(seen.x, p.getY(), seen.z) > 30 * 30) {
            aim = new Vec3d(seen.x, alt, seen.z);              // bay tới chỗ thấy lần cuối
        } else {                                               // tới nơi mà chưa thấy -> vòng xoắn rộng dần quanh đó
            double cx = seen != null ? seen.x : p.getX(), cz = seen != null ? seen.z : p.getZ();
            double r = Math.min(Math.max(40, c.maceRange * 0.8), 40 + searchT * 0.12);
            double th = Math.atan2(p.getZ() - cz, p.getX() - cx) + 0.6;
            aim = new Vec3d(cx + r * Math.cos(th), alt, cz + r * Math.sin(th));
        }
        Util.aim(p, aim);
        if (p.getY() - top < 10) p.setPitch(-25f);             // sát đất thì ngẩng lên
        rocket(mc, 1);
        return true;
    }

    /** mode 0: chỉ bắn khi bay lên / ngang (đang rơi hoặc chúi xuống thì không); 1: đuổi - bắn cả khi đang rơi nhưng phải ngẩng mũi; 2: lao pháo - bắn kể cả chúi xuống. */
    static boolean rocket(MinecraftClient mc, int mode) {
        Config c = Config.I; var p = mc.player;
        if (!c.maceUseRocket || rocketCd > 0) return false;
        double sp = p.getVelocity().length();
        if (mode == 0) { if (sp >= 1.1 || p.getVelocity().y < -0.3 || p.getPitch() > 5f) return false; }
        else if (mode == 1) { if (sp >= 1.7 || p.getPitch() > 5f) return false; }
        else if (sp >= 1.9) return false;
        if (!Util.selectItem(s -> s.isOf(Items.FIREWORK_ROCKET))) return false;
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        rocketCd = mode == 2 ? 8 : 14;
        return true;
    }

    /** Mô phỏng rơi tự do (bỏ cánh) từ trạng thái hiện tại xuống thấp h block: {số tick, trôi x, trôi z}. */
    static double[] fallSim(net.minecraft.client.network.ClientPlayerEntity p, double h) {
        Vec3d v = p.getVelocity();
        double y = 0, x = 0, z = 0, vy = v.y, vx = v.x, vz = v.z;
        int n = 0;
        while (y > -h && n < 160) {
            vy = (vy - 0.08) * 0.98; y += vy;
            x += vx; z += vz; vx *= 0.91; vz *= 0.91;
            n++;
        }
        return new double[]{n, x, z};
    }

    /** Bỏ lượt / đập xong: đeo lại cánh (cd ngắn) và làm vòng mới. */
    private static void abort(MinecraftClient mc) { release(mc); cd = 1; }

    private static void dive(MinecraftClient mc, PlayerEntity t, double dist) {
        Config c = Config.I; var p = mc.player;
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double above = p.getY() - t.getY();
        if (!t.isAlive()) { abort(mc); return; }

        // ===== GIAI ĐOẠN 0: vẫn đeo cánh, bay (lao) tới sát đối thủ =====
        if (stage == 0) {
            if (!Util.chestIs(Util::isElytra)) {
                if (cd == 0 && Util.equipChest(Util::isElytra, false)) cd = 3;
                return;
            }
            if (!p.isGliding()) {
                if (p.isOnGround()) { abort(mc); return; }
                openElytra(mc);                     // đang rơi / bị hất lên: spam Space để mở cánh lại
                return;
            }
            if (horiz > c.maceHorizDive * 2 + 10 || above < (quick ? -1.0 : 2.0)) { abort(mc); return; }   // đối thủ chạy/pearl đi chỗ khác
            if (!quick && c.maceBallistic && c.maceStyle == 0) {
                // Lao chéo vào người sẽ bị cánh đổi đà thành bay vọt lên qua đầu. Thay vào đó: bay ngang phía trên đầu,
                // tính đà rơi, tới điểm mà "thả ra là rơi trúng đầu" thì đổi áo + rơi thẳng xuống.
                double head = t.getY() + t.getHeight();
                double[] sim = fallSim(p, p.getY() - head);
                double err = Math.hypot(p.getX() + sim[1] - (t.getX() + tvx * sim[0]), p.getZ() + sim[2] - (t.getZ() + tvz * sim[0]));
                boolean high = p.getY() - head >= Math.max(5.0, c.maceDiveDist * 0.6);
                if (high && err <= c.maceDropErr) { stage = 1; cd = 0; return; }
                Vec3d to = high ? new Vec3d(t.getX() + tvx * 4, p.getEyeY(), t.getZ() + tvz * 4)
                                : new Vec3d(t.getX(), t.getY() + c.maceDiveDist + 8, t.getZ());
                Util.aim(p, to);
                rocket(mc, 0);
                return;
            }
            if (c.maceStyle == 1) {                       // LAO PHÁO: nhắm đón đầu rồi bắn pháo lao thẳng xuống
                double lead = Math.min(8, dist / 1.8);
                Util.aim(p, t.getPos().add(tvx * lead, t.getHeight() * 0.5, tvz * lead));
                rocket(mc, 2);
            } else {
                Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
                rocket(mc, 0);
            }
            double swap = quick ? c.maceChainSwap : c.maceSwapDist;
            if (!quick && c.maceStyle == 1) swap = Math.max(6, Math.min(c.maceSwapDist, p.getVelocity().length() * 4 + 2));   // lao pháo: để dành chỗ cho pháo, đổi áo muộn theo tốc độ
            if (dist <= swap && above > (quick ? 0.5 : 3.0)) { stage = 1; cd = 0; }
            return;
        }

        // ===== GIAI ĐOẠN 1: đổi sang áo (hết bay), rơi xuống đập =====
        if (hitFlag) { hitFlag = false; abort(mc); return; }                            // bạn vừa tự đập xong -> làm vòng mới
        double abortH = (!quick && c.maceBallistic) ? c.maceHorizDive + 12 : c.maceAbortDist;   // thả từ xa nên cho phép lệch ngang lớn hơn
        if (horiz > abortH || above < (quick ? -0.5 : 0)) { abort(mc); return; }
        if (c.maceSwapChest && (p.isGliding() || Util.chestIs(Util::isElytra))) {
            if (cd == 0) { Util.equipChest(Util::isChestplate, true); cd = 2; }
            if (p.isGliding()) p.stopGliding();
            return;
        }
        // đối thủ đang giơ khiên chặn -> đổi rìu đập phá khiên trước
        if (c.maceAxe && c.maceAutoHit && t.isBlocking() && dist <= c.maceHitDist && Util.has(s -> s.isIn(ItemTags.AXES))) {
            Util.selectItem(s -> s.isIn(ItemTags.AXES));
            Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
            mc.options.forwardKey.setPressed(true); keysHeld = true;
            if (axeCd == 0 && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
                mc.interactionManager.attackEntity(p, t);
                p.swingHand(Hand.MAIN_HAND);
                axeCd = 12;
            }
            return;
        }
        if (!Util.selectItem(s -> s.isOf(Items.MACE))) { Util.warn("Không có mace!"); release(mc); return; }
        Util.aim(p, t.getPos().add(0, t.getHeight() * (c.maceBallistic ? 1.0 : 0.5), 0));
        if (horiz > 0.8) { mc.options.forwardKey.setPressed(true); keysHeld = true; } else mc.options.forwardKey.setPressed(false);

        // mace smash (rơi > 1.5 block, không bay) KHÔNG cần cooldown đầy -> đập ngay khi tới tầm, đừng chờ rồi lướt qua đầu
        boolean smash = p.fallDistance > 1.5 && !p.isGliding();
        if (c.maceAutoHit && dist <= c.maceHitDist && (smash || p.getAttackCooldownProgress(0.5f) >= 0.9f)) {
            mc.interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
            if (c.maceChain) chain = 80;
            abort(mc);          // đập xong: đeo cánh lại, bị hất nhẹ thì lao xuống đập tiếp
        }
    }
}
