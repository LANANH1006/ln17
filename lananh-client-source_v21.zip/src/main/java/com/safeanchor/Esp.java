package com.safeanchor;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public class Esp {
    record Bx(Box box, int rgb, int alpha) { Bx(Box box, int rgb) { this(box, rgb, -1); } }
    static java.util.List<Box> ghostCache = new ArrayList<>();
    static long lastGhost = -100;
    record Tr(Vec3d to, int rgb) {}

    public static int countPlayers(MinecraftClient mc) {
        int n = 0;
        for (PlayerEntity o : mc.world.getPlayers()) if (o != mc.player && !o.isSpectator() && o.squaredDistanceTo(mc.player) <= Config.I.espRange * Config.I.espRange) n++;
        return n;
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config c = Config.I;
        if (!c.enabled || mc.player == null || mc.world == null) return;
        if (!(c.espPlayers || c.espMobs || c.espStorage || c.espBlocks || c.pearlGlow || c.trajOn || c.schemGhost || c.susOn)) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;
        Camera cam = ctx.camera();
        Vec3d cp = cam.getPos();
        float td = ctx.tickCounter().getTickDelta(false);
        double r2 = c.espRange * c.espRange;

        List<Bx> boxes = new ArrayList<>();
        List<Tr> tracers = new ArrayList<>();

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || e.isRemoved() || e.squaredDistanceTo(mc.player) > r2) continue;
            boolean player = e instanceof PlayerEntity pe && !pe.isSpectator();
            boolean mob = e instanceof MobEntity;
            if (!((player && c.espPlayers) || (mob && c.espMobs))) continue;
            Vec3d lerp = e.getLerpedPos(td);
            Box b = e.getBoundingBox().offset(lerp.subtract(e.getPos()));
            int col = c.chroma ? Util.chroma(e.getId() * 0.07) : (player ? c.espPlayerColor : c.espMobColor);
            boxes.add(new Bx(b, col));
            addTracer(tracers, c, player ? c.trPlayer : c.trMob, b.getCenter(), col);
        }

        if (c.espStorage) {
            int rad = (int) Math.ceil(c.espRange / 16.0);
            int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
            for (int cx = pcx - rad; cx <= pcx + rad; cx++) for (int cz = pcz - rad; cz <= pcz + rad; cz++) {
                WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (ch == null) continue;
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    int col, tr;
                    if (be instanceof EnderChestBlockEntity) { col = c.espEnderColor; tr = c.trEnder; }
                    else if (be instanceof ShulkerBoxBlockEntity) { col = c.espShulkerColor; tr = c.trShulker; }
                    else if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) { col = c.espChestColor; tr = c.trChest; }
                    else continue;
                    if (Vec3d.ofCenter(be.getPos()).squaredDistanceTo(mc.player.getPos()) > r2) continue;
                    Box b = new Box(be.getPos());
                    boxes.add(new Bx(b, col));
                    addTracer(tracers, c, tr, b.getCenter(), col);
                }
            }
        }

        if (c.espBlocks) {
            double br = c.espBlkRange * c.espBlkRange;
            for (BlockEsp.Hit h : BlockEsp.hits()) {
                if (Vec3d.ofCenter(h.pos()).squaredDistanceTo(mc.player.getPos()) > br) continue;
                Box b = new Box(h.pos());
                boxes.add(new Bx(b, h.color(), c.espBlkAlpha));
                addTracer(tracers, c, c.trBlock, b.getCenter(), h.color());
            }
        }
        if (c.pearlGlow) for (net.minecraft.util.math.BlockPos bp : Util.pearlBlocks()) boxes.add(new Bx(new Box(bp), c.pearlGlowColor));
        List<Vec3d> traj = null;
        if (c.trajOn) {
            Traj.Result tr = Traj.compute(mc, td);
            if (tr != null) {
                traj = tr.pts;
                if (tr.land != null) boxes.add(new Bx(new Box(tr.land), c.pearlGlowColor));
                if (tr.hit != null) boxes.add(new Bx(tr.hit.getBoundingBox().offset(tr.hit.getLerpedPos(td).subtract(tr.hit.getPos())), c.pearlGlowColor));
            }
        }
        List<Box> ghost = ghostCache;
        if (c.susOn) {
            double py = mc.player.getY() - 0.05;
            for (long k : SusChunk.hot.keySet()) {
                net.minecraft.util.math.ChunkPos cpos = new net.minecraft.util.math.ChunkPos(k);
                if (Math.abs(cpos.x - (mc.player.getBlockX() >> 4)) > 10 || Math.abs(cpos.z - (mc.player.getBlockZ() >> 4)) > 10) continue;
                boxes.add(new Bx(new Box(cpos.getStartX(), py, cpos.getStartZ(), cpos.getStartX() + 16, py + 0.1, cpos.getStartZ() + 16), 0xFF0000, 70));
            }
        }
        if (c.schemGhost && !Printer.blocks.isEmpty() && Printer.origin != null) {
          long nowT = mc.world.getTime();
          if (nowT - lastGhost >= 10 || nowT < lastGhost) {
            lastGhost = nowT; ghostCache = new ArrayList<>(); ghost = ghostCache;
            net.minecraft.util.math.BlockPos pc = mc.player.getBlockPos();
            int gr = 12;
            for (int dx = -gr; dx <= gr && ghost.size() < 1500; dx++) for (int dy = -gr; dy <= gr; dy++) for (int dz = -gr; dz <= gr; dz++) {
                net.minecraft.util.math.BlockPos q = pc.add(dx, dy, dz);
                var want = Printer.blocks.get(q.subtract(Printer.origin).asLong());
                if (want == null || mc.world.getBlockState(q).isOf(want.getBlock())) continue;
                ghost.add(new Box(q));
            }
          }
        } else if (!ghostCache.isEmpty()) { ghostCache = new ArrayList<>(); ghost = ghostCache; }
        if (boxes.isEmpty() && traj == null && ghost.isEmpty()) return;
        boolean hasLines = (c.espMode != 1 && !boxes.isEmpty()) || !tracers.isEmpty() || (traj != null && traj.size() > 1) || !ghost.isEmpty();

        Matrix4f m = ms.peek().getPositionMatrix();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        if (c.espMode != 0 && !boxes.isEmpty()) {
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (Bx b : boxes) fill(bb, m, b.box.offset(-cp.x, -cp.y, -cp.z), b.rgb, b.alpha >= 0 ? b.alpha : c.espAlpha);
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        if (hasLines) {
        RenderSystem.lineWidth(2f);
        BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        if (c.espMode != 1) for (Bx b : boxes) outline(lb, m, b.box.offset(-cp.x, -cp.y, -cp.z), b.rgb);
        Vec3d f = Vec3d.fromPolar(cam.getPitch(), cam.getYaw());
        Vec3d up = Vec3d.fromPolar(cam.getPitch() - 90f, cam.getYaw());
        for (Tr t : tracers) {
            Vec3d o = tracerOrigin(f, up, t.rgb);
            Vec3d to = t.to.subtract(cp);
            int col = t.rgb & 0xFFFFFF;
            line(lb, m, o, to, col, 255);
        }
        if (traj != null) for (int i = 1; i < traj.size(); i++) line(lb, m, traj.get(i - 1).subtract(cp), traj.get(i).subtract(cp), c.pearlGlowColor, 255);
        for (Box g : ghost) outline(lb, m, g.offset(-cp.x, -cp.y, -cp.z), 0x40C0FF);
        BufferRenderer.drawWithGlobalProgram(lb.end());
        }

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    // rgb có bit 24-25 chứa loại dây (1 trên, 2 giữa, 3 dưới)
    static void addTracer(List<Tr> list, Config c, int mode, Vec3d to, int col) {
        if (mode <= 1) return;           // chế độ 1 (dây trên cùng giữa màn hình) đã bỏ
        int color = col;
        if (c.tracerOwnColor) color = mode == 1 ? c.tracerColor1 : mode == 2 ? c.tracerColor2 : c.tracerColor3;
        list.add(new Tr(to, (mode << 24) | (color & 0xFFFFFF)));
    }
    static Vec3d tracerOrigin(Vec3d f, Vec3d up, int packed) {
        int mode = packed >>> 24;
        double h = (mode == 1 ? 0.5 : mode == 3 ? -0.5 : 0.0) + Config.I.tracerOffset / 100.0;
        return f.multiply(1.0).add(up.multiply(h));
    }

    static void v(VertexConsumer b, Matrix4f m, double x, double y, double z, int rgb, int a) {
        b.vertex(m, (float) x, (float) y, (float) z).color((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, a);
    }
    static void line(VertexConsumer b, Matrix4f m, Vec3d a, Vec3d c, int rgb, int alpha) {
        v(b, m, a.x, a.y, a.z, rgb, alpha); v(b, m, c.x, c.y, c.z, rgb, alpha);
    }
    static void outline(VertexConsumer b, Matrix4f m, Box x, int rgb) {
        double x0 = x.minX, y0 = x.minY, z0 = x.minZ, x1 = x.maxX, y1 = x.maxY, z1 = x.maxZ;
        double[][] e = {{x0,y0,z0,x1,y0,z0},{x1,y0,z0,x1,y0,z1},{x1,y0,z1,x0,y0,z1},{x0,y0,z1,x0,y0,z0},
                {x0,y1,z0,x1,y1,z0},{x1,y1,z0,x1,y1,z1},{x1,y1,z1,x0,y1,z1},{x0,y1,z1,x0,y1,z0},
                {x0,y0,z0,x0,y1,z0},{x1,y0,z0,x1,y1,z0},{x1,y0,z1,x1,y1,z1},{x0,y0,z1,x0,y1,z1}};
        for (double[] l : e) { v(b, m, l[0], l[1], l[2], rgb, 255); v(b, m, l[3], l[4], l[5], rgb, 255); }
    }
    static void fill(VertexConsumer b, Matrix4f m, Box x, int rgb, int a) {
        double x0 = x.minX, y0 = x.minY, z0 = x.minZ, x1 = x.maxX, y1 = x.maxY, z1 = x.maxZ;
        double[][] q = {{x0,y0,z0,x1,y0,z0,x1,y0,z1,x0,y0,z1},{x0,y1,z0,x0,y1,z1,x1,y1,z1,x1,y1,z0},
                {x0,y0,z0,x0,y1,z0,x1,y1,z0,x1,y0,z0},{x0,y0,z1,x1,y0,z1,x1,y1,z1,x0,y1,z1},
                {x0,y0,z0,x0,y0,z1,x0,y1,z1,x0,y1,z0},{x1,y0,z0,x1,y1,z0,x1,y1,z1,x1,y0,z1}};
        for (double[] f : q) for (int i = 0; i < 12; i += 3) v(b, m, f[i], f[i + 1], f[i + 2], rgb, a);
    }
}
