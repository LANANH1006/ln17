package com.safeanchor;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** Nền menu tùy chỉnh: Tối / Màu / Gradient / Ảnh (đặt file PNG vào .minecraft/config/lananh-bg.png). */
public class MenuBg {
    static final Identifier ID = Identifier.of("safeanchor", "dynamic_bg");
    static Identifier tex; static int tw, th; static long stamp = -1;

    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("lananh-bg.png"); }

    /** Nạp lại ảnh khi file đổi. */
    static void refresh() {
        try {
            Path p = file();
            long st = Files.exists(p) ? Files.getLastModifiedTime(p).toMillis() : -2;
            if (st == stamp) return;
            stamp = st;
            var tm = MinecraftClient.getInstance().getTextureManager();
            if (tex != null) { tm.destroyTexture(ID); tex = null; }
            if (st == -2) return;
            try (InputStream in = Files.newInputStream(p)) {
                NativeImage img = NativeImage.read(in);
                tw = img.getWidth(); th = img.getHeight();
                tm.registerTexture(ID, new NativeImageBackedTexture(img));
                tex = ID;
            }
        } catch (Throwable t) { tex = null; }
    }

    /** Nhân alpha của màu ARGB theo mức "Trong suốt" của menu. */
    public static int a(int argb) {
        int tr = Config.I.uiTrans;
        if (tr <= 0) return argb;
        int al = (int) (((argb >>> 24) & 0xFF) * (1.0 - Math.min(90, tr) / 100.0));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    public static void draw(DrawContext ctx, int w, int h, int px, int pw) {
        int mode = ModuleManager.bgMode == null ? 0 : ModuleManager.bgMode.index;
        int c1 = ModuleManager.bgC1 == null ? 0x0B0B14 : (ModuleManager.bgC1.argb() & 0xFFFFFF);
        int c2 = ModuleManager.bgC2 == null ? 0x2A1650 : (ModuleManager.bgC2.argb() & 0xFFFFFF);
        int dim = ModuleManager.bgDim == null ? 90 : ModuleManager.bgDim.geti();
        int panel = ModuleManager.bgPanel == null ? 240 : ModuleManager.bgPanel.geti();
        if (mode == 3) {
            refresh();
            if (tex != null && tw > 0 && th > 0) {
                double sw = Math.min(tw, th * (double) w / h), sh = sw * h / w;      // cắt giữa ảnh cho vừa khung (cover)
                ctx.drawTexture(RenderLayer::getGuiTextured, tex, 0, 0, (float) ((tw - sw) / 2), (float) ((th - sh) / 2), w, h, (int) sw, (int) sh, tw, th);
            } else mode = 0;
        }
        switch (mode) {
            case 1 -> ctx.fill(0, 0, w, h, 0xFF000000 | c1);
            case 2 -> ctx.fillGradient(0, 0, w, h, 0xFF000000 | c1, 0xFF000000 | c2);
            case 0 -> ctx.fill(0, 0, w, h, 0xFF0B0B14);
            default -> {}
        }
        if (dim > 0) ctx.fill(0, 0, w, h, a(Math.min(255, dim) << 24));
        if (panel > 0) {
            ctx.fill(px - 4, 0, px + pw + 4, h, a((Math.min(255, panel) << 24) | 0x161624));
            ctx.fill(px - 4, 0, px - 3, h, 0xFF8B5CF6); ctx.fill(px + pw + 3, 0, px + pw + 4, h, 0xFF8B5CF6);
        }
    }
}
