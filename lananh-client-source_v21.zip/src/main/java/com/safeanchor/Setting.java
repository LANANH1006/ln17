package com.safeanchor;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/** Một mục cài đặt của module: Mode / Slider / Checkbox / Keybind / Color. */
public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }
    abstract void save(JsonObject o);
    abstract void load(JsonObject o);
    /** Chữ ký giá trị: đổi khi người dùng chỉnh (để biết khi nào cần đẩy sang Config). */
    long sig() { return 0; }

    // ---------- Mode: bấm để đổi chế độ ----------
    public static class Mode extends Setting {
        public final String[] options; public int index;
        public Mode(String name, int def, String... options) { super(name); this.options = options; this.index = def; }
        public String get() { return options[index]; }
        public boolean is(String s) { return options[index].equalsIgnoreCase(s); }
        public void next() { index = (index + 1) % options.length; }
        public void prev() { index = (index + options.length - 1) % options.length; }
        long sig() { return index; }
        void save(JsonObject o) { o.addProperty(name, index); }
        void load(JsonObject o) { if (o.has(name)) index = Math.floorMod(o.get(name).getAsInt(), options.length); }
    }

    // ---------- Slider: kéo để chỉnh Range / Speed / Delay ----------
    public static class Slider extends Setting {
        public final double min, max, step; public double value;
        public Slider(String name, double def, double min, double max, double step) { super(name); this.value = def; this.min = min; this.max = max; this.step = step; }
        public double get() { return value; }
        public int geti() { return (int) Math.round(value); }
        public float getf() { return (float) value; }
        public void setFrac(double f) {
            double v = min + Math.max(0, Math.min(1, f)) * (max - min);
            if (step > 0) v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }
        public double frac() { return (value - min) / (max - min); }
        public String text() { return step >= 1 ? String.valueOf((int) Math.round(value)) : String.format("%.2f", value); }
        long sig() { return Double.doubleToLongBits(value); }
        void save(JsonObject o) { o.addProperty(name, value); }
        void load(JsonObject o) { if (o.has(name)) value = Math.max(min, Math.min(max, o.get(name).getAsDouble())); }
    }

    // ---------- Checkbox: bật / tắt tính năng phụ ----------
    public static class Check extends Setting {
        public boolean value;
        public Check(String name, boolean def) { super(name); this.value = def; }
        public boolean get() { return value; }
        long sig() { return value ? 1 : 0; }
        void save(JsonObject o) { o.addProperty(name, value); }
        void load(JsonObject o) { if (o.has(name)) value = o.get(name).getAsBoolean(); }
    }

    // ---------- Keybind: phím tắt bật/tắt module ----------
    public static class Key extends Setting {
        public int key = -1; public boolean listening;
        public Key(String name) { super(name); }
        public String label() {
            if (listening) return "...bấm 1 phím (Esc = bỏ, Del = xóa)";
            if (key < 0) return "Chưa gán";
            try { return net.minecraft.client.util.InputUtil.fromKeyCode(key, 0).getLocalizedText().getString(); }
            catch (Throwable t) { return "#" + key; }
        }
        long sig() { return key; }
        void save(JsonObject o) { o.addProperty(name, key); }
        void load(JsonObject o) { if (o.has(name)) key = o.get(name).getAsInt(); }
    }

    // ---------- Color: màu + Alpha + Rainbow ----------
    public static class Color extends Setting {
        public int rgb; public int alpha = 255; public boolean rainbow; public boolean open;
        public Color(String name, int rgb) { super(name); this.rgb = rgb & 0xFFFFFF; }
        /** Màu ARGB hiện tại (rainbow tự đổi theo thời gian). */
        public int argb() {
            int c = rainbow ? java.awt.Color.HSBtoRGB((System.currentTimeMillis() % 4000L) / 4000f, 0.8f, 1f) & 0xFFFFFF : rgb;
            return (alpha << 24) | c;
        }
        long sig() { return rgb * 31L + alpha + (rainbow ? 1000003L * (System.currentTimeMillis() / 50) : 0); }
        void save(JsonObject o) { JsonObject c = new JsonObject(); c.addProperty("rgb", rgb); c.addProperty("a", alpha); c.addProperty("rb", rainbow); o.add(name, c); }
        void load(JsonObject o) {
            JsonElement e = o.get(name);
            if (e != null && e.isJsonObject()) { JsonObject c = e.getAsJsonObject(); rgb = c.get("rgb").getAsInt(); alpha = c.get("a").getAsInt(); rainbow = c.get("rb").getAsBoolean(); }
        }
    }
}
